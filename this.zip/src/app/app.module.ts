import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DocumentPreviewComponent } from './document-preview/document-preview.component';
import { DocumentDetailsComponent } from './document-details/document-details.component';
import { SafePipe } from './safe.pipe'; 

@NgModule({
  declarations: [
    AppComponent,
    DocumentPreviewComponent,
    DocumentDetailsComponent,
    SafePipe, 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
