import { Component } from '@angular/core';  
import * as a from "../assets/json/test.json"; 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'OCR - The power of ML';
  documentName = 'assets/pdf/file1.pdf'; 
  constructor(){  
  } 
  update(event:any){
    // this.documentName = 'assets/pdf/file2.pdf' + event.target.id;  
    console.log(a[0]);
  }
}
